#!/usr/bin/env python
# coding: utf-8

# In[3]:


# Use input function to ask the user if they want to calculate the area of a trapezoid or triangle.
shape = input("Would you like to calculate the area of a triangle or a trapezoid? ")

# Using if, elif, and else statements to run certain code depending on what the input from the user was.
# Within the if statement I ask for the base and height of the triangle, then compute the area using those values as floats.
if shape == "triangle":
    base = input("Enter the base of the triangle: ")
    height = input("Enter the height of the triangle: ")
    area = 0.5 * float(base) * float(height)
    print(f"The area of the triangle is: {area} units")

# Within the elif statement I ask for bases a and b and the height of the trapezoid, then compute the area using those values as floats.
elif shape == "trapezoid":
    a = input("Enter the length of the first base of the trapezoid: ")
    b = input("Enter the length of the second base of the trapezoid: ")
    height = input("Enter the height of the trapezoid: ")
    area = 0.5 * (float(a) + float(b)) * float(height)
    print(f"The area of the trapezoid is: {area} units")

# An addition telling the user they have entered something other than 'triangle' or 'trapezoid'.
else:
    print("Invalid shape choice!")

