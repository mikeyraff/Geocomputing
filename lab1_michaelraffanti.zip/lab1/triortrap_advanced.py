#!/usr/bin/env python
# coding: utf-8

# In[3]:


# Definition that utilizes the try and except functions to ensure the prompt/input is a numeric value.
# The except statement checks for a value error, which would include entering a non-numeric input and prints a statement for the user to try again.
def is_num(prompt):
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Invalid input! Please enter a numeric value.")

shape = input("Would you like to calculate the area of a triangle or a trapezoid? (Enter 'triangle' or 'trapezoid'): ")

if shape == "triangle":
    base = is_num("Enter the base of the triangle: ")
    height = is_num("Enter the height of the triangle: ")
    area = 0.5 * base * height
    print(f"The area of the triangle is: {area} units")

elif shape == "trapezoid":
    a = is_num("Enter the length of the first base of the trapezoid: ")
    b = is_num("Enter the length of the second base of the trapezoid: ")
    height = is_num("Enter the height of the trapezoid: ")
    area = 0.5 * (a + b) * height
    print(f"The area of the trapezoid is: {area} units")

else:
    print("Invalid shape choice!")

