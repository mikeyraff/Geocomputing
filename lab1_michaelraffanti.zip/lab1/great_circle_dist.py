#!/usr/bin/env python
# coding: utf-8

# In[6]:


import math

# Created a definition that takes in the 4 coordinate inputs and converts them to radian values, which can be used for the equation.
def greater_distance(lat1, lon1, lat2, lon2):    
    lat1 = math.radians(lat1)
    lon1 = math.radians(lon1)
    lat2 = math.radians(lat2)
    lon2 = math.radians(lon2)
    
    # Using the math module and inputs, the angle is calcualted and later multiplied by the radius of the Earth to get spherical distance
    angle = math.acos((math.sin(lat1) * math.sin(lat2)) + (math.cos(lat1) * math.cos(lat2) * math.cos(lon1 - lon2)))
    R = 6300
    d = angle * R
    return d

if __name__ == "__main__":
    # Prompts  the user for input coordinates for both locations, floats them to accept decimal degrees
    lat1 = float(input("Enter the latitude of Location 1: "))
    lon1 = float(input("Enter the longitude of Location 1: "))
    lat2 = float(input("Enter the latitude of Location 2: "))
    lon2 = float(input("Enter the longitude of Location 2: "))

    # Calls my defintions and converts to a float for good measure
    distance = greater_distance(lat1, lon1, lat2, lon2)
    distance = float(distance)
    print(f"The distance between the two locations is: {distance} km")

