#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Create the function that takes in three arguments
def dms_to_dd(degree, minute, second):
# Ensuring that if the inputted degree value is negative, the function assumes minute and second is also negative
    if degree < 0:
        minute = -1 * minute
        second = -1 * second
# Part of the function that does the conversion from DMS to DD and returns it
    dd = degree + (minute/60) + (second/3600)
    return dd
# An example to test it using the numbers from the Lab 2 PDF
example = dms_to_dd(-40, 26, 46)
print(example)


# In[2]:


# Create the function that takes in just one argument
def dd_to_dms(dd):
# Computating the value of the three parameters and making sure they are of the form int
    degree = int(dd)
    minute = int((dd - degree) * 60)
    second = round(((dd - degree) * 60 - minute) * 60)
# Using abs() to ensure minute and second are returned positive
    return degree, abs(minute), abs(second)
# An exmaple to test it using the number from the Lab 2 PDF
example = dd_to_dms(-79.982)
print(example)


# In[4]:


# Create the main function that takes in user input
def main():
    user_input = input("Enter DD or DMS value: ")
# Using a ',' as an indicator to know if the input was in the form DMS or DD
# Uses the split function to divide the DMS input into three parts that is used to convert DMS to DD
    if "," in user_input:
        degree, minute, second = map(int, user_input.split(','))
        print(f"The DD form is: {dms_to_dd(degree, minute, second)}")
    else:
# Ensures the user DD input is of the form float and calls the function to do the conversion
        dd = float(user_input)
        d, m, s = dd_to_dms(dd)
        print(f"The DMS form is: {d},{m},{s}")
# Included the below if-statement so that when the cell is run it calls the main() function
if __name__ == "__main__":
    main()

