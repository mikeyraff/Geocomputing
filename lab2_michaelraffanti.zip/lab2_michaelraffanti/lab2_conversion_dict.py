city = ["Tokyo","New Delhi","Sao Paulo","Mumbai","Mexico City","New York","Shanghai","Kolkata","Buenos Aires", "Los Angeles", "Beijing","Rio de Janeiro"]
population = [23.3,3.53,7.62,5.81,8.77,16.19,6.04,6.93,0,0,8.1,8.38]


# Create empty dictionary that we will use a loop to add stuff to
cityPop = {}
# Use a for loop to through the city list each city a time
for i in range(len(city)):
# After each instance in the for loop, the cityPop gets a new item which has 
# cities as the key matched to the corrseponding populations as the values of the dictionary
    cityPop[city[i]] = population[i]
# Prints the dictionary after for loop finishes
print(cityPop)
